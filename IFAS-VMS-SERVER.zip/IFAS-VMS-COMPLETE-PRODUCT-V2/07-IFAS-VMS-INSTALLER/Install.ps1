#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$SourceRoot = $PSScriptRoot,
    [string]$InstallRoot = "$env:ProgramFiles\IFAS\IFAS VMS",
    [string]$DataRoot = "$env:ProgramData\IFAS\IFAS VMS",
    [switch]$SkipShortcuts
)

$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Please run this installer as Administrator."
    }
}

function Copy-IfExists([string]$source, [string]$destination) {
    if (Test-Path $source) {
        New-Item -ItemType Directory -Force -Path $destination | Out-Null
        Copy-Item -Path $source -Destination $destination -Recurse -Force
    }
}

Assert-Administrator

Write-Host "Installing IFAS VMS..." -ForegroundColor Cyan

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null

Copy-IfExists (Join-Path $SourceRoot "Published\Server") (Join-Path $InstallRoot "Server")
Copy-IfExists (Join-Path $SourceRoot "Published\Client") (Join-Path $InstallRoot "Client")
# Supplier-only License Manager is intentionally NOT copied by the client/server installer.
# Install it separately on the supplier workstation using Supplier-Install.ps1.

Copy-IfExists (Join-Path $SourceRoot "Config") (Join-Path $DataRoot "Config")
Copy-IfExists (Join-Path $SourceRoot "Keys") (Join-Path $DataRoot "Keys")

if (-not $SkipShortcuts) {
    $startMenu = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\IFAS VMS"
    New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

    $clientExe = Join-Path $InstallRoot "Client\IFAS.VMS.Client.exe"
    if (Test-Path $clientExe) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut((Join-Path $startMenu "IFAS VMS Client.lnk"))
        $shortcut.TargetPath = $clientExe
        $shortcut.WorkingDirectory = Split-Path $clientExe
        $shortcut.Save()
    }
}

Write-Host "IFAS VMS installation files copied successfully." -ForegroundColor Green
Write-Host "Install: $InstallRoot"
Write-Host "Data:    $DataRoot"
